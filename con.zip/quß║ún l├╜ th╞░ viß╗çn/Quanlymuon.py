##modules
import customtkinter as ctk
import tkinter,webbrowser
from tkinter import *
from tkinter import messagebox
from datetime import date
import os,pathlib,openpyxl,xlrd
from openpyxl import Workbook
import requests,sys
from bs4 import BeautifulSoup
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")
import openpyxl
#start
root=ctk.CTk()
root.iconbitmap('D:\quản lý thư viện\.ico\logo.ico')
root.title('Quản Lý Người Mượn Sách')
root.geometry('1190x610+210+100')
root.resizable(False,False)
colortext='white'
ds_admin=[]
file='.file_need\\admin.txt'
from pathlib import Path
my_file = Path(".file_need\\admin.txt")
if not my_file.is_file():
    my_file.touch()
with open('.file_need\\admin.txt','w') as n:
    n.write('Admin')
    n.close()
with open('.file_need\\admin.txt','r') as f:
    f=f.read()
    a=f.split(',')
    for i in range(len(a)):
        ds_admin.append(a[i])
file=pathlib.Path('DANH_SACH_MUON.xlsx')
if file.exists():
    pass
else:
    file=Workbook()
    sheet=file.active
    sheet['A1']='Đăng ký số:'
    sheet['B1']='Tên'
    sheet['C1']='Lớp'
    sheet['D1']='Giới Tính'
    sheet['E1']='Ngày Đăng Ký'
    sheet['F1']='Địa chỉ'
    sheet['G1']='Thông Tin Liên Lạc'
    sheet['H1']='Tên Sách Mươn'
    sheet['I1']='Mượn Ngày:'
    sheet['J1']='Ngày Trả'
    sheet['K1']='Trách Nhiệm'
    sheet['L1']='Người Xét Duyệt'
    file.save('DANH_SACH_MUON.xlsx')
##label1
def acp(event):
    webbrowser.open("https://facebook.com/nguyen30112007")
link_label=ctk.CTkLabel(root,text='thông tin liên lạc:ostmay37@gmail.com',width=10,height=3,anchor='e', cursor="hand2")
link_label.pack_configure(side='top',fill='x')
link_label.bind("<Button-1>", acp)
qlms=ctk.CTkLabel(root,text='Quản Lý Mượn Sách',width=10,height=2,cursor="hand2")
qlms.pack_configure(side='top',fill='x')
qlms.bind("<Button-2>")
##widget

search_et=ctk.CTkEntry(master=root,placeholder_text="Tìm Kiếm")
search_et.place(x=720,y=50)
search_bt=ctk.CTkButton(master=root,text='Tìm kiếm',compound=LEFT,width=123,command=lambda:messagebox.showinfo('Tìm Kiếm','Chức Năng này đang cập nhật'))
search_bt.place(x=870,y=50)
update_tt=ctk.CTkButton(master=root,text='Cập Nhật Thông Tin',command=lambda:messagebox.showinfo('Thông Tin','Dữ Liệu Đang Được Cập Nhật'))
update_tt.place(x=1030, y = 50 )
ds_lb=ctk.CTkLabel(root,text='Danh sách mượn số:')
ds_lb.place(x=20,y=100/2)
reg=ctk.CTkEntry(root,placeholder_text='Thêm số không được trùng số trước đó')
reg.place(x=160,y=100/2)
today=date.today()
d1=today.strftime("%d/%m/20%y")
date_et=ctk.CTkEntry(root,placeholder_text=d1)
date_et.place(x=450,y=100/2)
#frame
lb_frame=ctk.CTkFrame(root,width=850,height=350)
lb_frame.place(x=20,y=180)
ten_lb=ctk.CTkLabel(lb_frame,text='Tên',text_color=colortext)
ten_lb.place(x=30,y=10)
lop_lb=ctk.CTkLabel(lb_frame,text='Lớp',text_color=colortext)
lop_lb.place(x=30,y=70)
place_lb=ctk.CTkLabel(lb_frame,text='Địa chỉ',text_color=colortext)
place_lb.place(x=30,y=130)
cto_lb=ctk.CTkLabel(lb_frame,text='Thông Tin Liên Lạc',text_color=colortext)
cto_lb.place(x=30,y=190)
book_name_lb=ctk.CTkLabel(lb_frame,text='Tên Sách',text_color=colortext)
book_name_lb.place(x=450,y=10)
han_lb=ctk.CTkLabel(lb_frame,text='Hạn',text_color=colortext)
han_lb.place(x=450,y=70)
luuy_lb=ctk.CTkLabel(lb_frame,text='Trách Nhiệm Nếu Hư Sách',text_color=colortext)
luuy_lb.place(x=450,y=130)
admin_duyet_lb=ctk.CTkLabel(lb_frame,text='Người Duyệt',text_color=colortext)
admin_duyet_lb.place(x=450,y=190)
#entry
name_et=ctk.CTkEntry(lb_frame,placeholder_text='Tên')
name_et.place(x=180,y=10)
lop_et=ctk.CTkEntry(lb_frame,placeholder_text='Lớp')
lop_et.place(x=180,y=70)
place_et=ctk.CTkEntry(lb_frame,placeholder_text='Địa Chỉ')
place_et.place(x=180,y=130)
contact_et=ctk.CTkEntry(lb_frame,placeholder_text='CONTACT')
contact_et.place(x=180,y=190)
book_name_et=ctk.CTkEntry(lb_frame,placeholder_text='Tên Sách')
book_name_et.place(x=640,y=10)

han_et=ctk.CTkEntry(lb_frame,placeholder_text='Hạn')
han_et.place(x=640,y=70)
select_sb=ctk.StringVar()
ctk.CTkSegmentedButton(lb_frame,values=['Chấp Nhận','Bỏ qua'],variable=select_sb).place(x=640,y=130)
admin_op=ctk.CTkOptionMenu(lb_frame,values=ds_admin)
admin_op.place(x=640,y=190)
admin_op.set('Chọn Người Xét')
#frame2
def hdsd():
    c=ctk.CTkToplevel(root)
    bground='black'
    c.configure(bg=bground)
    c.title('Hướng dẫn sử dụng')
    c.mainloop()
def reset():
    root.destroy()
    os.system('py Quanlymuon.py')
frame2=ctk.CTkFrame(root,width=400,height=250)
frame2.place(x=890,y=300)
def save_data():
    # Open the Excel file and select the active sheet
    wb = openpyxl.load_workbook('DANH_SACH_MUON.xlsx')
    sheet = wb.active
    # Get the data from the Entry and OptionMenu widgets
    reg_num = reg.get()
    name = name_et.get()
    lop = lop_et.get()
    address = place_et.get()
    contact = contact_et.get()
    book_name = book_name_et.get()
    han = han_et.get()
    trachnhiem = select_sb.get()
    nguoiduyet = admin_op.get()
    if reg_num=='':
        messagebox.showerror("Lỗi", "Bạn chưa nhập số định danh")
    if name=='':
        messagebox.showerror("Lỗi","Bạn chưa nhập tên")
    if lop=='':
        messagebox.showerror("Lỗi", "Bạn chưa nhập lớp")
    elif address=='':
        messagebox.showerror("Lỗi", "Bạn chưa nhập địa chỉ")
    elif contact=='':
        messagebox.showerror("Lỗi","Bạn chưa nhập thông tin liên lạc")
    elif book_name=='':
        messagebox.showerror("Lỗi", "Bạn chưa nhập tên sách")
    elif han=='':
        messagebox.showerror("Lỗi", "Bạn chưa điền hạn trả sách")
    elif trachnhiem=='':
        messagebox.showerror("Lỗi","Hãy chịu trách nhiệm nếu bạn làm hư sách")
    elif nguoiduyet=='':
        messagebox.showerror("Lỗi","Bạn chưa chọn người duyệt")
    else:
        row_num = sheet.max_row + 1
    # Write the data to the appropriate cells
        sheet.cell(row=row_num, column=1, value=reg_num)
        sheet.cell(row=row_num, column=2, value=name)
        sheet.cell(row=row_num, column=3, value=lop)
        sheet.cell(row=row_num, column=5, value=d1)
        sheet.cell(row=row_num, column=6, value=address)
        sheet.cell(row=row_num, column=7, value=contact)
        sheet.cell(row=row_num, column=8, value=book_name)
        sheet.cell(row=row_num, column=9, value=han)
        sheet.cell(row=row_num, column=10, value=trachnhiem)
        sheet.cell(row=row_num, column=11, value=nguoiduyet)
        messagebox.showinfo('Thành Công','Đã Lưu Thành Công')
        reset()
        # Save the Excel file
        wb.save('DANH_SACH_MUON.xlsx')
def kdv():
    dialog = ctk.CTkInputDialog(text="Thêm Kiểm Duyệt Viên:", title="Kiểm Duyệt Viên")
    a=dialog.get_input()
    f=open('.file_need\\admin.txt','a')
    f.write(f',{a}')
    messagebox.showinfo('Thành Công','Thêm Kiểm Duyệt Viên Thành Công')
def reset_all():
    os.remove('.file_need\\admin.txt')
    os.remove('DANH_SACH_MUON.xlsx')
    messagebox.showinfo('Thành Công','Khôi Phục Thành Công')
    root.destroy()
def check_color():
    a=radio_var.get()
    global colortext
    if a==2:
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")
        colortext='white'
        ten_lb.configure(text_color=colortext)
        lop_lb.configure(text_color=colortext)
        place_lb.configure(text_color=colortext)
        cto_lb.configure(text_color=colortext)
        han_lb.configure(text_color=colortext)
        admin_duyet_lb.configure(text_color=colortext)
        luuy_lb.configure(text_color=colortext)
        book_name_lb.configure(text_color=colortext)
        cto_lb.configure(text_color=colortext)
    elif a==1:
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")
        colortext='black'
        ten_lb.configure(text_color=colortext)
        lop_lb.configure(text_color=colortext)
        place_lb.configure(text_color=colortext)
        cto_lb.configure(text_color=colortext)
        han_lb.configure(text_color=colortext)
        admin_duyet_lb.configure(text_color=colortext)
        luuy_lb.configure(text_color=colortext)
        book_name_lb.configure(text_color=colortext)
        cto_lb.configure(text_color=colortext)
def check_update():
    messagebox.showinfo('Cập nhật','Sẽ có')
#Bảng thông báo
bt_1=ctk.CTkButton(frame2,text='Lưu Người Mượn',command=save_data)
bt_1.place(x=0,y=0)
bt_2=ctk.CTkButton(frame2,text='Xoá Hạn')
bt_2.place(x=150,y=0)
bt_3=ctk.CTkButton(frame2,text='Làm Mới',command=reset)
bt_3.place(x=0,y=50)
bt_4=ctk.CTkButton(frame2,text='Thêm Kiểm Duyệt Viên',command=kdv)
bt_4.place(x=150,y=50)
bt_5=ctk.CTkButton(frame2,text='Mở Tệp',command=lambda:os.startfile('DANH_SACH_MUON.xlsx'))
bt_5.place(x=0,y=100)
bt_6=ctk.CTkButton(frame2,text='Kiểm tra bản mới',command=check_update)
bt_6.place(x=150,y=100)
bt_7=ctk.CTkButton(frame2,text='Hướng dẫn sử dụng')
bt_7.place(x=0,y=150)
bt_8=ctk.CTkButton(frame2,text='Khôi Phục cài đặt gốc',command=reset_all)
bt_8.place(x=150,y=150)
radio_var= tkinter.IntVar(value=0)
radiobutton_1 = ctk.CTkRadioButton(frame2, text='Sáng',
                                             command=check_color, variable= radio_var, value=1).place(x=50,y=200)
radiobutton_2 = ctk.CTkRadioButton(frame2, text="Tối",
                                             command=check_color, variable= radio_var, value=2).place(x=200,y=200)
#Bảng thông báo hạn
frame3=ctk.CTkFrame(root,width=1000,height=400)
frame3.place(x=890,y=200)

def MovingText(s):
    #Lấy ký tự đầu ghép vào cuối
    s1 = s[1:len(s)]
    s2 = s[0:1]
    string = s1 + s2
    #Hiển thị nội dung chữ
    label.configure(text = string)
    a.configure(text=b)
    #Gọi lại hàm Moving sau 1/10 giây
    label.after(500,MovingText,string)
btb=ctk.CTkLabel(frame3,text='Bảng thông báo',width=10,height=2,cursor="hand2")
btb.pack_configure(side='top',fill='x')
btb.bind("<Button-2>")
label = ctk.CTkLabel(frame3)
label.pack(anchor = 'center')
string = '       Chào Mừng Bạn đến tới ứng dụng của tôi'
a=ctk.CTkLabel(frame3)
a.pack(anchor='center')
b='Chưa có Bản Cập Nhật '
MovingText(string)
root.mainloop()