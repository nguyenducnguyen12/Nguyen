N,a,b=map(int,input().split())
def sum_bricks(A, B, N):
    total_bricks = 0   # Khởi tạo biến tổng số viên gạch
    bricks_on_level = A   # Khởi tạo số viên gạch trên hàng đỉnh
    for i in range(N):
        total_bricks += bricks_on_level * (i+1)   # Cộng tổng số viên gạch trên hàng i vào biến tổng
        bricks_on_level += B   # Tính số viên gạch trên hàng i+1
    return total_bricks   # Trả về tổng số viên gạch cần dùng để xếp thành tháp gạch
print(sum_bricks(N,a,b))